from django.apps import AppConfig


class KasirConfig(AppConfig):
    name = 'kasir'
